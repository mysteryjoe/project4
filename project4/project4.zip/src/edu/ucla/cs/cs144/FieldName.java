package edu.ucla.cs.cs144;

public class FieldName {
	public static final String ItemName = "ItemName";	
	public static final String Category = "Category";	
	public static final String SellerId = "SellerId";	
	public static final String BuyPrice = "BuyPrice";	
	public static final String BidderId = "BidderId";	
	public static final String EndTime = "EndTime";		
	public static final String Description = "Description";	// java.lang.String
}
