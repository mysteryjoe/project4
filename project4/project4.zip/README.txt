I use default.html as the page for user to choose the searching method.

For keyword search, numResultstoskip is 0 and numResultstoReturn is 20.

For item search, if nothing returned, there would be an error page allowing the user to return to the default page.

I used a css file available on the web to make the website more user friendly.
Please use 1 day of grace period.